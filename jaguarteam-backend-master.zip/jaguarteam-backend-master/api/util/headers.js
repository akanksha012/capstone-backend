const headers = {
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Allow-Credentials": true
};

export default headers;